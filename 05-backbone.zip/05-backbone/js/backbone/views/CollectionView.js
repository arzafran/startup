define(['jquery', 'backbone', 'handlebars', 'EditView', 'Movie', 'serialize'], function ($, Backbone, Handlebars, EditView, Movie, serializeObject) {
   var CollectionView = Backbone.View.extend({
        initialize: function(){
            this.render();
            this.listenTo(this.collection, 'add remove change' , function(){
                localStorage.setItem("movies",JSON.stringify(this.collection.models) );
                this.render();
            });
        },
        render: function(){
          var source = $("#billboard-template").html();
          var template = Handlebars.compile(source);
          this.$el.html(template(JSON.parse(localStorage.getItem("movies"))));
          $('#page').html(this.$el);
        },
        events: {
          "click .btn.add": "add",
          "click .btn.delete": "delete",          
          "click .btn.edit" : "edit",
          "click #save": "saveData"
        },
        delete: function(){
          this.collection.remove(this.collection.at(event.target.id));
          window.location.reload(true);
        },
        add: function(){
          var add = new EditView();
          added = add.render();
        },
        edit: function(){
          var editableMovie = this.collection.at(event.target.id).toJSON();
          var edit = new EditView();
          edit.render(editableMovie);
        },
        saveData: function(){
          alert(event.target.id);
        }
    });
  return CollectionView;
});


/*                  if(movie){
            this.collection.add(Movie);
          }
          var newData = {};
          $("#data").children("input[type='text']").each(function(i, el) {
            newData[el.id] = $(el).val(); 
          });
          $("#data").children("textarea[id='synopsis']").each(function(i, el) {
            newData[el.id] = $(el).val(); 
          });
          var newMovie = new Movie.Model(newData);
          console.log(newMovie);
          this.collection.add(newMovie);   
          var newMovie = new Movie.Model(newData);
          Collection.add(newMovie); 
          localStorage.setItem("movies",JSON.stringify(this.collection));*/