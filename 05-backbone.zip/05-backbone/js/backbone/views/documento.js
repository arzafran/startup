<button id="vemos">Agregar</button>
<button id="borramos">Borrar</button>
<script>
$(document).ready(function(){
$('#vemos').click(function(){
var tontoyretonto = '{"title":"Tonto y Retonto","Anio":"2002"}';
localStorage.setItem('name',tontoyretonto);
console.log(localStorage.getItem('name'));
});

$("borramos").click(function(){
localStorage.clear();
alert('Datos enviados, su información ha sido borrada de localStorage');
});	
});	
</script>


		if (o.titulo == "") {
			alert("Nombre vacio!!")
		}else {
		var len = localStorage.length;
		if (len == 0) {
			localStorage.setItem("1", JSON.stringify(o));
		}else {
		var flag = 0;
		for (x=0; x<=localStorage.length-1; x++)  {  
  			clave = localStorage.key(x);
  			 moviel =(JSON.parse(localStorage.getItem(clave))) ;
  			 if (moviel.titulo == o.titulo) {
  			 		flag = 1;
  			 }
			}
		if (flag==1) {
			alert("Esa peli ya esta cargada!!");
		}else{
		var index = len - 1;
		var key = parseInt(localStorage.key(index)) + 1;
		console.log("save");
		localStorage.setItem(key, JSON.stringify(o));
		}
		}
		}