define(["backbone","handlebars"], function(Backbone,Handlebars){
	var EditView = Backbone.View.extend({
		template: Handlebars.compile($('#edit-template').html()),
		render: function(movie){
      $('body').html(this.template(movie));
      return this;
		},
		events :{
			"click .btn.save" : "save"
		},
		save: function(){
			alert("lalalala");
		}
	});
	return EditView;
});